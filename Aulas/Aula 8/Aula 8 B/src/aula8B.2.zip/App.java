public class App {
    public static void main(String[] args) throws Exception {
        Agenda agendinha =new Agenda(4);

       agendinha.addInformacoes();
       agendinha.exibe();
    }
}
