public class App {
    public static void main(String[] args) throws Exception {
        Agenda agendinha =new Agenda(8);

       agendinha.addInformacoes();
       agendinha.exibe();
    }
}
