public interface Tributavel {
    double calculaTributos();
}
