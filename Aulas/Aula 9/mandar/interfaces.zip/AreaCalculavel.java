interface AreaCalculavel{
    double calculaArea();
}