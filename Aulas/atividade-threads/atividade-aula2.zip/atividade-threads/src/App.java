public class App {
    public static void main(String[] args){
        CorridaDeSapo corrida1=new CorridaDeSapo(5, 
        5);  
        corrida1.criaSapos();   
    }
}
